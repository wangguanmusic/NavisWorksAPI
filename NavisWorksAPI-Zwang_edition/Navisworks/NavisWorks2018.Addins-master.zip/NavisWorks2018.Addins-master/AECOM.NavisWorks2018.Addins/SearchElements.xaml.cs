﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using NW = Autodesk.Navisworks.Api;
using Autodesk.Navisworks.Api.Automation;
using ServiceStack.Text;


namespace AECOM.NavisWorks2018.Addins
{
    /// <summary>
    /// Interaction logic for SearchElements.xaml
    /// </summary>
    public partial class SearchElements : UserControl
    {
        public SearchElements(NW.Document doc)
        {
            InitializeComponent();
            document = doc;
        }

        //define parameter
        NW.Document document; 


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //Define Properties
            List<string> elementIDs = new List<string>();
            List<ElementTracking> elementTrackings = new List<ElementTracking>();

            #region Set NWD files to be searched
            System.Windows.Forms.FolderBrowserDialog FD = new System.Windows.Forms.FolderBrowserDialog();
           // System.Windows.Forms.OpenFileDialog FD = new System.Windows.Forms.OpenFileDialog();
            if (FD.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                string rootFolder = FD.SelectedPath;
                System.IO.FileInfo File = new System.IO.FileInfo(rootFolder);
                FilePath.Text = rootFolder;

                List<string> masterFiles = new List<string>();

                string[] allFiles = Directory.GetFiles(rootFolder, "*.nwd", SearchOption.AllDirectories);
                for (int i = 0; i < allFiles.Length; i++)
                {
                    if (allFiles[i].Contains("MASTER"))
                    {
                        masterFiles.Add(allFiles[i]);
                    }
                }
                #endregion

                //get list of elementID
                using(var reader = new StreamReader(@"C:\Users\xiaoxuan.peng\Desktop\NWD Files\Element Ids.csv"))
                {
                    while(!reader.EndOfStream)
                    {
                        var line = reader.ReadLine();
                        var values = line.Split(';');
                        foreach (var item in values)
                        {
                            elementIDs.Add(item);
                        }
                        MessageBox.Show(elementIDs.Count.ToString());
                    }
                }
                //MessageBox.Show(masterFiles.Count.ToString());

                foreach (string nwFile in masterFiles)
                {
                    
                    document.OpenFile(nwFile);

                    
                    //Search by property
                    
                    foreach (string id in elementIDs)
                    {
                        //Search elements with 4D schedule information
                        NW.Search search = new NW.Search();
                        search.Selection.SelectAll();
                        int count;

                        search.SearchConditions.Add(NW.SearchCondition.HasPropertyByDisplayName("Element ID", "Value").EqualValue(NW.VariantData.FromDisplayString(id)));
                        // execute search
                        try
                        {
                            NW.ModelItemCollection items = search.FindAll(document, true);
                            count = items.Count;
                            ElementTracking elementTracking = new ElementTracking();
                            elementTracking.FilePath = nwFile;
                            if (count > 0)
                            {
                                elementTracking.Existence = true;
                            }
                            else
                            {
                                elementTracking.Existence = false;
                            }
                            elementTracking.Submital = Directory.GetParent(nwFile).Name;
                            elementTracking.EliementID = id;
                            elementTrackings.Add(elementTracking);

                        }
                        catch (Exception ex)
                        {

                            MessageBox.Show(ex.Message);
                        }
                    }
                    
                }

                AECOM.NavisWorks2018.Addins.Functions.ConvertToCSV.convertToCSV(elementTrackings, @"C:\Users\xiaoxuan.peng\Desktop\NWD Files\Generated Reports.csv");
            }

            
        }
    }

    

    public class ElementTracking
    {
        private bool existence;
        private string submital;
        private string filePath;
        private string elementID;

        public bool Existence
        {
            get { return existence; }
            set
            {
                existence = value;
            }
        }
        public string Submital
        {
            get { return submital; }
            set
            {
                submital = value;
            }
        }

        public string FilePath
        {
            get { return filePath; }
            set
            {
                filePath = value;
            }
        }

        public string EliementID
        {
            get { return elementID; }
            set
            {
                elementID = value;
            }
        }
    }
}
