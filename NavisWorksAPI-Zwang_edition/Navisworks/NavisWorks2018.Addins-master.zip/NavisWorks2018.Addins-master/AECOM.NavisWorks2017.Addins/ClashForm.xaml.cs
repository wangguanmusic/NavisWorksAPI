﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AECOM.NavisWorks2018.Addins
{
    /// <summary>
    /// Interaction logic for ClashForm.xaml
    /// </summary>
    public partial class ClashForm : UserControl
    {
        public ClashForm()
        {
            //Initial the form
            InitializeComponent();
            //Create demo data object A
            List<Selection> catCollectionsA = new List<Selection>
           {
               
           };
            //Create demo data object B
            List<Selection> catCollectionsB = new List<Selection>
           {
               
           };

            //Add data to form source
            selectionA.ItemsSource = catCollectionsA;
            selectionB.ItemsSource = catCollectionsB;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            //string result = "";

            //foreach (var item in selectionA.ItemsSource)
            //{
            //    result += item.ToString() + ", ";
            //}

            //MessageBox.Show(result.Trim(' ', ','));
            List<string> listA = new List<string>();
            List<string> listB = new List<string>();

            foreach(var item in selectionA.ItemsSource)
            {
                listA.Add(item.ToString());
            }

            foreach (var item in selectionB.ItemsSource)
            {
                listB.Add(item.ToString());
            }
            MessageBox.Show("number of selectionA " + listA.Count.ToString() + "/n" +
                            "number of selectionB " + listB.Count.ToString() + "/n");
            AECOM.NavisWorks2018.Addins.Functions.CreateClashTest.createClashTest("New Test", listA, listB);
            
        }

       

    }

    public class Selection
    {
        //public string selection { get; set; }
        public string cat { get; set; }

        public override string ToString()
        {
            return cat;
        }
    }

    public class categoryList : List<string>
    {
        public categoryList()
        {
            this.Add("Ceiling");
            this.Add("Wall");
            this.Add("Door");
            this.Add("Window");
            this.Add("Pipe");
            this.Add("Duct");
            this.Add("Casework");
        }

    }
    
    
}
