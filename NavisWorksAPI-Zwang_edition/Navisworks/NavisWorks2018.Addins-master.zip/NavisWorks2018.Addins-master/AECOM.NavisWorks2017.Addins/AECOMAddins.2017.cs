﻿using System;
using System.Linq;
//using System.Windows.Forms;
using Autodesk.Navisworks.Api.Plugins;
using NW = Autodesk.Navisworks.Api;
using Autodesk.Navisworks.Api.Timeliner;
using AECOM.NavisWorks2018.Addins;
using System.Windows;
using System.Collections.Generic;
using System.Diagnostics;

namespace AECOM
{

    [Plugin("AECOMAddins", "Xiaoxuan Peng", DisplayName = "Xiaoxuan")]

    [Strings("CustomRibbon_V2017.name")]

    [RibbonLayout("CustomRibbon_V2017.xaml")]

    [RibbonTab("ID_CustomTab_1", DisplayName = "AECOM")]


    [Command("ID_Button_1", DisplayName = "Create Timeline Task", Icon = "Schedule_16.png", LargeIcon = "Schedule_32.png", ToolTip = "Create tasks based on object properties", ExtendedToolTip = "Properties need to be created from Revit and read from NavisWorks.")]
    [Command("ID_Button_2", DisplayName = "Create Clash Test", Icon = "Clash_16.png", LargeIcon = "Clash_32.png", ToolTip = "Create clash test", ExtendedToolTip = "Create clash test with code")]

    public class AECOMAddins : CommandHandlerPlugin
    {
        /// <summary>
        /// Constructor, just initialises variables.
        /// </summary>
        public AECOMAddins()
        {

        }

        /// <summary>
        /// Executes a command when a button in the ribbon is pressed.
        /// </summary>
        /// <param name="commandId">Identifies the command associated with the button 
        /// that was pressed, by the Id defined in the command attribute.</param>
        /// <param name="parameters">Not currently used by Navisworks. If command is
        /// invoked programmatically by plugin author it can be used to pass additional
        /// information.</param>
        /// <returns>Not used by Navisworks. If command is invoked programmatically by 
        /// plugin author then it can be used to return additional information.</returns>
        public override int ExecuteCommand(string commandId, params string[] parameters)
        {
            switch (commandId)
            {
                case "ID_Button_1":
                    {
                        //Define target document and elements
                        NW.Document doc = NW.Application.ActiveDocument;
                        DocumentTimeliner doc_TL = NW.Application.ActiveDocument.GetTimeliner();
                        NW.GroupItem groupItem = doc_TL.TasksRoot.CreateCopy() as NW.GroupItem;
                       

                        //Get Object Information and create objects to pass in WPF
                        List<ObjectInfo> objectInfos = new List<ObjectInfo>();
                        int count = 0; 

                        
                        //Search elements with 4D schedule information
                        NW.Search search = new NW.Search();
                        search.Selection.SelectAll();
                        //Search by property
                        search.SearchConditions.Add(NW.SearchCondition.HasPropertyByDisplayName("Element", "4D_Task_ID"));
                        
                        // execute search
                        try
                        {
                            NW.ModelItemCollection items = search.FindAll(doc, true);
                            count = items.Count;
                            
                            //MessageBox.Show(count.ToString());
                            foreach (NW.ModelItem item in items)
                            {
                                ObjectInfo objectInfo = new ObjectInfo();
                                objectInfo.objectName = item.DisplayName;

                                //Get element's 4D Task ID
                                objectInfo.objectTask = item.PropertyCategories.FindPropertyByDisplayName("Element", "4D_Task_ID").Value.ToInt32().ToString();
                                objectInfo.objectId = item.PropertyCategories.FindPropertyByDisplayName("Element", "Id").Value.ToInt32().ToString();
                                objectInfo.objectPhase = item.PropertyCategories.FindPropertyByDisplayName("Element", "4D_Task_Phase").Value.ToInt32().ToString();

                                objectInfos.Add(objectInfo);
                               
                            }

                            
                        }
                        catch (Exception ex)
                        {

                            MessageBox.Show(ex.Message);
                        }


                        //Initiate window
                        ScheduleSetting schedule = new ScheduleSetting(objectInfos, doc, doc_TL, groupItem, count);
                        schedule.BeginInit();

                        Window window = new Window()
                        {
                            Content = schedule,
                            Name = "Schedule",
                            Title = "Schedule"
                        };

                        if ( window.ShowDialog() == true)
                        {
                            //schedule.ScheduleResult();
                            schedule.CalculateValue();
                            
                            MessageBox.Show("Window is ok");
                        }

                        

                        break;
                    }
                case "ID_Button_2":
                    {
                        ClashForm clashForm = new ClashForm();

                        clashForm.BeginInit();
                        Window window = new Window()
                        {
                            Content = clashForm,
                            Name = "ClashTestForm",
                            Title = "Clash Test Form"
                        };

                        if (window.ShowDialog() == true)
                        {
                            //schedule.ScheduleResult();


                            System.Windows.MessageBox.Show("Window is ok");
                        }

                        break;
                    }
                default:
                    {
                        MessageBox.Show("This is a dfault message!");
                        break;
                    }
            }

            return 0;
        }

       

       

    }
}
